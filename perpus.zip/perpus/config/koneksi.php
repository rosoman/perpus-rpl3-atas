<?php
	//File koneksi
	$host		= "localhost";
	$user		= "root";
	$pwd		= "";
	$db			= "si_perpus_roso";

	//mendeklarasikan object con dan  menginisialisasi
	$con = new mysqli($host,$user,$pwd,$db);

	//Jika tidak konek berikan informasi dan code berhenti
	if($con->connect_error){
		die("Koneksi ke database Gagal! Keteranngan <br>: ".$con->connect_error);
	}

?>