<?php 

	die("Dirctory ini tidak bisa diakses!");

?>