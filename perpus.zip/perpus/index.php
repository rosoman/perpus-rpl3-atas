<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Perpus TB:</title>
	<style type="text/css">
		body{
			margin : 0;
		}
		#header {
			background-color: black;
			height: 50px; /* em px cm %  */
			width: 100%;
			margin: 0;
		}

		#wrapper-logo{
			height: 100%;
			align: center;
			line-height: 50px;
		}

		img{
			margin-right: auto;
			display: block;
			padding-top: 5px;
			padding-left: 5px;
			float: left;
		}

		#logo-text{
			color: white;
			font-weight: bolder;
			margin: 5px;
		}
		
		#nav-bar{
			box-sizing: border-box;
			width: 100%;
			height: 25px;
			text-align: right;
			padding-left: 10px;
			padding-right: 10px;
		}

		.btn-nav{
			text-decoration: none;
			padding: 5px;
			font-family: Arial;
			height: 100%;
			line-height: 25px;
			color: white;
		}

		.btn-nav:hover{
			border: dotted white 1px;
			background-color: darkblue;
		}

		.btnLinkMaster{
			box-sizing: border-box;
			padding:  5px 10px;
			background-color: #5ebcff;
			color: white;
			margin-top: 5px;
			height: 50px ;
			text-align: center;
			line-height: 50px;
			text-decoration: none;
			border-radius: 5px;
		}

		.btnLinkMaster:hover{
			background-color: #3daeff;
		}

		#content{
			width: 75%;
			position: absolute;
			padding: 10px;
			background-color: #d4edff;
			left: 50%;
			transform: translate(-50%);
			border: 1px dotted #3daeff;
		}

		#content table{
			margin: auto;
			width: 100%;
			border-collapse: collapse;
			font-family: Arial;
		}

		#content th, td{
			border-bottom: 1px solid #0087e8;
			padding: 5px;
		}

		#content th{
			background-color: #3daeff;
			color: white;
		}

		#content tr:hover {
			background-color: #f0f9ff;
		}

	</style>
</head>
<body>
	<div id="header" >
		<div id="wrapper-logo">
			<img width="50" src="img/logo.png">
			<span id="logo-text">Perpustakaan TB</span>
		</div>
	</div>
	<div id="nav-bar" style="background: #75b1ff;">
		<div id="nav-item">
			<a class="btn-nav" href="?">Beranda</a>
			<a class="btn-nav" href="?menu=siswa">Siswa</a>
			<a class="btn-nav" href="?menu=buku">Buku</a>
			<a class="btn-nav" href="#">Peminjaman</a>
			<a class="btn-nav" href="#">Pengguna</a>
		</div>
	</div>
	<div id="content">
		<!-- ini adalah tempat untuk menampilkan
			tabel menu diatas -->
			<?php
				if(isset($_GET['menu'])){
					if($_GET['menu'] == "siswa"){
						include_once "siswa/siswa.php";
					}elseif($_GET['menu'] == "buku"){
						include_once "buku/buku.php";
					}
				}
				


			?>

	</div>
	<div id="footer">
		
	</div>
</body>
</html>