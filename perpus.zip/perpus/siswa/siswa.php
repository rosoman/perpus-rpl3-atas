<?php 
	require_once "config/koneksi.php";
?>
<a class="btnLinkMaster" href="siswa/frm_siswa.php">Input Data siswa</a>
<table>
	<caption>Tabel Data Siswa/Anggota</caption>
	<tr>
		<th>NIS</th>
		<th>NAMA</th>
		<th>JENIS KELAMIN</th>
		<th>ALAMAT</th>
		<th>CONTROL</th>
	</tr>
	<?php 
		$kueri = "SELECT * FROM tsiswa";
		$data = $con->query($kueri);
		while ($row=$data->fetch_assoc()) {
	?>
	<tr>
		<td><?php echo $row['nis']; ?></td>
		<td><?php echo $row['nama']; ?></td>
		<td><?php echo $row['jenisKelamin']=="L"? "Laki-laki" : "Perempuan"; ?></td>
		<td><?php echo $row['alamat']; ?></td>
		<td>-</td>
	</tr>
	<?php } ?>
</table>