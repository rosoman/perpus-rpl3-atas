<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Input Siswa</title>
	<style type="text/css">
		#form{
			width: 50%;
			margin:  auto;
			background-color: #d4e5ff;
			padding: 15px;
			border-radius: 10px;
			border: 1px solid #91bdff;

		}

		input[type=text]{
			box-sizing: border-box;
			display: inline-block;
			border: 1px #91bdff solid;
			margin: 3px 0 10px 0;
			padding: 10px 15px;
			border-radius: 5px;
			width: 100%;
		}

		input[type=radio]{
			box-sizing: border-box;
			display: inline-block;
			width: 20px;
		}

		textarea{
			box-sizing: border-box;
			display: inline-block;
			width: 100%;
			border: 1px #91bdff solid;
			margin: 3px 0 10px 0;
			padding: 10px 15px;
			border-radius: 5px;
			resize: vertical;
		}

		input[type=submit]{
			box-sizing: border-box;
			display: inline;
			width: 60%;
			background-color: #00ad06;
			color: white;
			border-radius: 0px 5px 5px 0;
			padding: 5px;
			border: solid 1px green;
			margin-bottom: 5px;
			margin-left: 0;
			height: 30px;

		}

		input[type=submit]:hover{
			/*font-weight: bolder;*/
			background-color: #008f05;
			cursor: pointer;
		}

		.marginLabel{
			box-sizing: border-box;
			display: block;
			margin-top: 10px;
			
		}

		input[type=reset]{
			box-sizing: border-box;
			display: inline;
			width: 20%;
			background-color: #fff1ad;
			margin-right: 0;
			border-radius: 5px 0 0 5px;
			padding: 5px;
			border: solid 1px green;
			border-right: none;
			margin-bottom: 5px;
			float: left;
			height: 30px;
		}

		input[type=reset]:hover{
			/*font-weight: bolder;*/
			background-color:#ffe97d;
			cursor: pointer;
		}

		.btnHome{
			box-sizing: border-box;
			display: inline;
			width: 20%;
			background-color: #fff1ad;
			margin-right: 0;
			border-radius: 0 0 0 0;
			padding: 5px;
			height: 30px;
			border: solid 1px green;
			border-right: none;
			margin-bottom: 5px;
			float: left;
			text-decoration: none;
			color: black;
			text-align: center;
		}

		.btnHome:hover{
			/*font-weight: bolder;*/
			background-color:#ffe97d;
			cursor: pointer;
		}

		.marginLabel{
			box-sizing: border-box;
			display: block;
			margin-top: 10px;
			
		}

		#judul-form{
			background-color: blue;
			width: 100%;
		}

		label{
			font-weight: bold;
			font-family: arial, perdana;
		}

		#judul-form{
			background: #4aa1ff;
			text-align: center;
			margin-bottom: 15px;
			padding: 10px;
			border-radius: 5px 5px 0 0;
			box-sizing: border-box;
			font-family: Arial, perdana;
			font-weight: bold;
			border-bottom: 2px solid blue;
			color: white;
		}
	</style>
</head>
<body>
	<div id="form">
		<div id="judul-form">Input Siswa</div>
		<form method="post" action="simpansiswa.php">
			<label for="in_nis">NIS</label>
			<input id="in_nis" maxlength="6" type="text" name="in_nis" placeholder="isi nis Anda">

			<label for="in_nis">Nama Siswa</label>
			<input id="in_nama" type="text" name="in_nama" placeholder="isi nama asli Anda">

			<label class="marginLabel" for="in_jk">Jenis Kelamin</label>
			<input id="in_jk" type="radio" name="in_jk" value="L">Laki-Laki
			<input id="in_jk" type="radio" name="in_jk" value="P">Perempuan
			<br>
			<label class="marginLabel" for="in_alamat">Alamat</label>
			<textarea id="in_alamat" name="in_alamat" placeholder="masukan alamat domisili sesuai KTP"></textarea>
			
			<input type="reset" name="btnreset">
			<a href="../?menu=siswa" class="btnHome">Beranda</a>
			<input type="submit" name="submit" value="Simpan">
			
		</form>
	</div>


</body>
</html>