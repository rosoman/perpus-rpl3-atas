<?php 
	require_once "../config/koneksi.php";

	$nis	= $_POST['in_nis'];
	$nama	= $_POST['in_nama'];
	$jk		= isset($_POST['in_jk'])? $_POST['in_jk'] : "";
	$alamat	= $_POST['in_alamat'];

	$data	= array(
				['l'=>"NIS",'d'=>$nis],
				['l'=>"NAMA",'d'=>$nama],
				['l'=>"JENIS KELAMIN",'d'=>$jk],
				['l'=>"ALAMAT",'d'=>$alamat]);
	
	/*echo "<pre>";
	
	print_r($data);
	echo "</pre>";
	die();*/

	// Validasi form kosong userfriendly
	$kosong = array();
	for($i = 0;$i < count($data); $i++){
		if ($data[$i]['d']=="") {
			$kosong[] = $data[$i]['l'];
		}
	}
	
	$errorGabungan="";
	if(!empty($kosong)){
		for ($i=0; $i < count($kosong); $i++) { 
			$errorGabungan .= $kosong[$i]." ";
		}
		
		die("Ada yang kosong kolom : ".$errorGabungan."<br><a href='javascript:history.go(-1);'>Kembali</a>");
	}

	// Cari datanya dulu biar egak bentrok
	$cari 	= "SELECT * FROM tsiswa WHERE nis='$nis'";
	$hasil 	= $con->query($cari);
	if ($hasil->num_rows>0) {
		
		$nama = $hasil->fetch_assoc();
		die('NIS siswa sudah ada! dengan nama: <b>'.$nama['nama'].'</b><br><a href=frm_siswa.php>Kembali</a>');
	}


	// Proses simpan
	$simpan = "INSERT INTO tsiswa(NIS, nama, jenisKelamin, alamat) VALUES('$nis','$nama','$jk','$alamat')";

	$hasil	= $con->query($simpan);

	if($hasil){
		echo "Data berhasil disimpan! <br><a href='frm_siswa.php'>Masukan Data Lagi</a> | <a href='../'>Menu Utama</a>";
	}else{
		echo "Menyimpan data gagal! <br>
			<a href='frm_siswa.php'>Ulang lagi</a>
			|<a href='../'>Menu Utama</a>"
		;

		echo "Errornya".$con->error;
	}

?>