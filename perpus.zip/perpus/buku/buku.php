<a href="#">Input Data Buku</a>
<table>
	<caption>Tabel Data Buku</caption>
	<tr>
		<th>NO. BUKU</th>
		<th>JUDUL</th>
		<th>PENGARANG</th>
		<th>PENERBIT</th>
		<th>TAHUN TERBIT</th>
		<th>STATUS</th>
		<th>CONTROL</th>
	</tr>
	<tr>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
</table>